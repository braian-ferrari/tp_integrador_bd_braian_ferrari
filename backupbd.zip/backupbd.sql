-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.2.0 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla integrador_cac.oradores: ~10 rows (aproximadamente)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `fecha_alta`) VALUES
	(1, 'Rosental', 'Alves', 'Rosental@gmail.com', 'Periodismo', '2019-11-11'),
	(2, 'Vanina', 'Berghella', 'Vanina@gmail.com', 'Plataformas Digitales', '2020-09-10'),
	(3, 'Mariano', 'Blejman', '', 'Innovacion en Medios', '2022-01-14'),
	(4, 'Felicitas', 'Carrique', 'Carrique@hotmail.com', 'Diseño de Productos', '2020-05-29'),
	(13, 'Diego', 'Agostino', 'dagostino@yahhoo.com', 'Operaciones Comerciales', '2018-10-09'),
	(14, 'Borja', 'Echeverria', 'Echeverria@gmail.com', 'Documentales', '2011-12-10'),
	(15, 'Liliana', 'Elosegui', 'lili@hotmail.com', 'Derechos Humanos', '2015-01-23'),
	(16, 'Octavio', 'Enriquez', 'Enriqueocta@gmail.com', 'Prensa', '2016-06-25'),
	(17, 'Lilian', 'Ferreira', 'Lilian@hotmail.com', 'Medias Digitales', '2023-01-12'),
	(18, 'Carlos Eduardo', 'Huertas', 'Carlitos@yahoo.com', 'Abusos de Poder', '2021-12-12');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
